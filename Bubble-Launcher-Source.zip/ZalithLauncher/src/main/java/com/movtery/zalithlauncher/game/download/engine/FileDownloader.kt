/*
 * Zalith Launcher 2
 * Copyright (C) 2025 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.game.download.engine

import com.movtery.zalithlauncher.utils.logging.Logger
import kotlinx.coroutines.CancellationException

private const val TAG = "FileDownloader"

/**
 * 单文件下载作业：优先尝试 [SegmentDownloader] 多线程分片下载，
 * 不可用时回落到 [Fetcher] 按候选源顺序单连接下载，期间把落盘字节计入 [stats]。
 */
class FileDownloader(
    private val request: DownloadRequest,
    private val stats: DownloadStats
) {
    suspend fun download() {
        val segmented = try {
            SegmentDownloader.tryDownload(
                urls = request.urls,
                targetFile = request.targetFile,
                sha1 = request.sha1,
                onBytes = stats::addBytes
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            Logger.warning(TAG, "Segmented download unavailable, using single connection", e)
            false
        }

        if (!segmented) {
            Fetcher.downloadFile(
                urls = request.urls,
                targetFile = request.targetFile,
                sha1 = request.sha1,
                onBytes = stats::addBytes
            )
        }
        //下载前未知大小的文件：分子已随下载计入，这里把实际大小补进分母
        if (request.expectedSize <= 0) {
            stats.registerBytes(request.targetFile.length())
        }
    }
}
